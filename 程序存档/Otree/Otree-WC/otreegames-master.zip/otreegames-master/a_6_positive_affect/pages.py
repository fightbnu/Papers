from otree.api import Currency as c, currency_range
from ._builtin import Page, WaitPage
from .models import Constants
import random

lists = [
            'Affect_1', 'Affect_2', 'Affect_3R', 'Affect_4R',
        ]

list_01 = lists[0:4]


class PAffect(Page):
    form_model = 'player'
    form_fields = list_01
    random.shuffle(form_fields)
    pass


page_sequence = [
    PAffect,
]
